# Geolocator Plugin details

Simple cross platform plugin to get GPS location including heading, speed, and more.

#### Features
* Async GPS Location Detection
* Heading
* Speed
* Listen for Changes


Works from any shared code or PCL project.

Find more plugins at: http://www.github.com/xamarin/plugins