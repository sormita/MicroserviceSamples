﻿using Xamarin.Forms;

namespace eShopOnContainers.Core.Controls
{
    public partial class AddBasketButton : ContentView
    {
        public AddBasketButton()
        {
            InitializeComponent();
        }
    }
}