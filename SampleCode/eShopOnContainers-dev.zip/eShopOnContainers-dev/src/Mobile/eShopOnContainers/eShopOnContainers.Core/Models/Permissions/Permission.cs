﻿namespace eShopOnContainers.Core.Models.Permissions
{
    public enum Permission
    {
        Unknown,
        Location,
        LocationAlways,
        LocationWhenInUse
    }
}
