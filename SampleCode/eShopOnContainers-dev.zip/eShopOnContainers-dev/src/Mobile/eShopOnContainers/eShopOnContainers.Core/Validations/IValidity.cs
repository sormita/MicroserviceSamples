﻿namespace eShopOnContainers.Core.Validations
{
    public interface IValidity
    {
        bool IsValid { get; set; }
    }
}
