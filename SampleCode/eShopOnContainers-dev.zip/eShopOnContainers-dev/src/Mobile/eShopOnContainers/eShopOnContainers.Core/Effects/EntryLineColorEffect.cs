﻿using Xamarin.Forms;

namespace eShopOnContainers.Core.Effects
{
	public class EntryLineColorEffect : RoutingEffect
	{
		public EntryLineColorEffect() : base("eShopOnContainers.EntryLineColorEffect")
		{
		}
	}
}
