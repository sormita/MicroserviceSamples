﻿namespace eShopOnContainers.Core.Services.Common
{
    public static class Common
    {
        public static string MockCatalogItemId01 = "1";
        public static string MockCatalogItemId02 = "2";
        public static string MockCatalogItemId03 = "3";
        public static string MockCatalogItemId04 = "4";
        public static string MockCatalogItemId05 = "5";

        public static int MockCampaignId01 = 1;
        public static int MockCampaignId02 = 2;
    }
}
