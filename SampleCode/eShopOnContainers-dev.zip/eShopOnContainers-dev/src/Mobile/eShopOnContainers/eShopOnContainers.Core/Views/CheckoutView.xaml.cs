﻿using Xamarin.Forms;

namespace eShopOnContainers.Core.Views
{
    public partial class CheckoutView : ContentPage
    {
        public CheckoutView()
        {
            InitializeComponent();
        }
    }
}
