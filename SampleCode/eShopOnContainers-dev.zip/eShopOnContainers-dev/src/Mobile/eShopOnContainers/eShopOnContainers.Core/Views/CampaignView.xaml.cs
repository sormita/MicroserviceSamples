﻿using Xamarin.Forms;

namespace eShopOnContainers.Core.Views
{
    public partial class CampaignView : ContentPage
    {

        public CampaignView()
        {
            InitializeComponent();
        }
    }
}