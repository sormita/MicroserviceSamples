# docker build

This folder contains the dockerfile and script to create the ocelot build container.