Contributing
============

Pull requests, issues and commentary welcome! No special process just create a request and get in 
touch either via gitter or create an issue. 