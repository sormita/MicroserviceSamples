﻿namespace Ocelot.Provider.Rafty
{
    public class FilePeer
    {
        public string HostAndPort { get; set; }
    }
}
