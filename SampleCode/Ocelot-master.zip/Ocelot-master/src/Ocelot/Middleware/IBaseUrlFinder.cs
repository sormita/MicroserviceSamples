﻿namespace Ocelot.Middleware
{
    public interface IBaseUrlFinder
    {
        string Find();
    }
}