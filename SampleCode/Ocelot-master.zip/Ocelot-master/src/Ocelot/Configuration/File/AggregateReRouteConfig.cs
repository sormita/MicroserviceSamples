﻿namespace Ocelot.Configuration.File
{
    public class AggregateReRouteConfig
    {
        public string ReRouteKey { get; set; }
        public string Parameter { get; set; }
        public string JsonPath { get; set; }
    }
}
