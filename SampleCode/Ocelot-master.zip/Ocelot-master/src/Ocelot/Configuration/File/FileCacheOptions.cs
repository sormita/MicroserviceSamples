﻿namespace Ocelot.Configuration.File
{
    public class FileCacheOptions
    {
        public int TtlSeconds { get; set; }
        public string Region { get; set; }
    }
}
