namespace Ocelot.DependencyInjection
{
    public interface IAdministrationPath
    {
        string Path { get; }
    }
}
